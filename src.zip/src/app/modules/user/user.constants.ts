export const userSearchableField = ['email', 'name', 'address', 'location'];
