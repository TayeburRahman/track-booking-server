type IGenericErrorMessage = {
  path: string | number;
  message: string;
};
export default IGenericErrorMessage;
