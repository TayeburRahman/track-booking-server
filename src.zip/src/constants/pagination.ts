const paginationFields = ['page', 'limit', 'sortBy', 'sortOrder'];
export default paginationFields;
