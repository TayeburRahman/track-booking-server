export const packageName = ['Basic', 'Standard', 'Premium'];
